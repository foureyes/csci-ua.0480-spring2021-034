const express = require('express');
const path = require('path');

// app object:
// * listen: bind to a port
// * get, post, put, etc.: ... add a route
// * use: activate middleware
// * set: configure your application
const app = express();

// app.set will allow us to configure our application
// set the templating system to handlebars
app.set('view engine', 'hbs');

// middleware is a function that takes 3 arguments:
// a request, a response, and a function to call called next (which is the next middleware function or
// the next route handler)
// middlewareFunc(req, res, next)
// to activate / register it ... app.use(middlewareFunc)
// this function will be called prior to any of the route handling
// can modify the req coming in or send back the response immediately
// ... or pass on control to next middleware / route
//
// express static
// 1. examines request.path... 
// 2. check for that file in public folder
// 3. if it exists, serve it
// 4. if it doesn't, call next middleware or route
const publicPath = path.join(__dirname, 'public');
app.use(express.static(publicPath));

const logger = (req, res, next) => {
  console.log(req.method, req.path, req.query);
  next();
};

app.use(logger);

// middleware that checks the Host: header of an http request
// if it exists OK!... go on to next middleware or route
// if it doesn't exist, send back a 400
app.use((req, res, next) => {
  if(req.get('Host')) {
    next();
  } else {
    res.status(400).send('invalid request');
  }
});

app.use(express.urlencoded({extended: false}));
// this gives us access to req.body
// req.body contains the parsed http request
// body (assuming it's in urlencoded format:
// name=val&name2=val2


// route handler
// it responds to a an http request based on method (GET) and path (/)
// ... use get to add rourtes, first argument is path
// second arg is callback... that will get called when a request to GET /
// comes in ...it will be invoked with a request and response object
// an instance of Request: path, method, query, params, body *, get (for headers)
// an instance of Response: status(), send(), sendFile(), ... render()
// one of the methods above must be called to end the req/res cycle ^^^
app.get('/', (req, res) => {
  res.send('<h1>my fav adventure time character</h1>');
});

app.get('/form', (req, res) => {
  res.render('form');
});

app.post('/action', (req, res) => {
  console.log('got this body', req.body);
  res.redirect('/form');
});

app.get('/product', (req, res) => {
  const num1 = parseInt(req.query.num1);
  const num2 = parseInt(req.query.num2);
  const product = num1 * num2;
  console.log(product);
  res.render('calculate', {result: product});
  // res.status(200).send(isNaN(product) ? 'not a number' : '' + product);
});

app.get('/pb', (req, res) => {

  const shows = [
    {name: 'at', year:2012},
    {name: 'gravity falls'}
  ];

  const kingdoms = {
    'candy': 'pb', 
    'ice': 'ice king', 
  };
  const context = {
    character1: 'princess bubblegum!!!!!!!',
    character2: 'peppermint butler',
    favs: ['pb', 'pepbut', 'magic man'],
    places: kingdoms,
    shows: shows
  };
  res.render('pb', context);
});






app.listen(3000);
