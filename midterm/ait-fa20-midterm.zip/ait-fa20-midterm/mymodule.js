const fs = require('fs');

////////////////
// QUESTION 1 //
////////////////

function pledge() {
  return `I pledge that the work in this exam submission is my own. I did not receive any help in constructing my solutions. I understand that the following resources are allowed:

1. my own notes and homework solutions
2. online documentation for the technologies involved
3. online resources that are not directly related to the exam question (for example, an existing stackoverflow post to debug a runtime exception is allowed)

I also understand that using resources outside of those listed above (such as _actually_ asking a question on a Q&A forum, receiving help from another student, etc.) or sharing my own answers will be considered an academic integrity violation.

[YOUR NAME HERE!]
`
}

////////////////
// QUESTION 2 //
////////////////
//
// function a() {
// }

// function b() {
// }

// function c() {
// }

// function d() {
// }


////////////////
// QUESTION 3 //
////////////////

// function e() {
// }

////////////////
// QUESTION 4 //
////////////////

// function f() {
//}

////////////////
// QUESTION 5 //
////////////////
  
// function g() {
// }

////////////////
// QUESTION 6 //
////////////////
  
// function all(arr, result, test) {
// }
 
// function makeKeyAgg(fn) {
// }


// UNCOMMENT EXPORTS AS NEEDED
module.exports = {
  // pledge,
  // a,
  // b,
  // c,
  // d,
  // e,
  // f,
  // g,
  // all, 
  // makeKeyAgg
};
