const fs = require('fs');
const path = require('path');
const express = require('express');
const app = express();
app.set('view engine', 'hbs');
app.use(express.urlencoded({ extended: false }));

// DO NOT REMOVE THIS LINE OR ADD ANOTHER LISTEN
module.exports = app.listen(3000);

