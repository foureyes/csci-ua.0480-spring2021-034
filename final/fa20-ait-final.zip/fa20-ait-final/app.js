const express = require('express');
const app = express();
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));

const mongoose = require('mongoose');

const CourseSchema = new mongoose.Schema({
  number: String,
  name: String,
  description: String
});

mongoose.model('Course', CourseSchema);
const Course = mongoose.model('Course');
mongoose.connect('mongodb://localhost/fa20-ait-final');

// TODO: (q02) add API endpoints

app.listen(3000);
