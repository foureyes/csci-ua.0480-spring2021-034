document.addEventListener("DOMContentLoaded", main);

function getURL(url, cb) {
  const xhr = new XMLHttpRequest();
  xhr.open('GET', url);
  xhr.addEventListener('load', function() {
    if(xhr.status >= 200 && xhr.status < 400) {
      cb(JSON.parse(xhr.responseText)); 
    } 
  });
  xhr.send();
}

function main() {
  // TODO: (q02) implement main
}
