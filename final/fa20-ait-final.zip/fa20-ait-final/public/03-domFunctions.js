function createElement(...args) {
  // TODO: (q03) implement createElement
}

function mountElement(ele, mountPoint) {
  // TODO: (q03) implement mountElement
}

const h3 = createElement('h3', {}, 'hello');
const p = createElement('p', {className: 'foo'}, 'this is a wallaby');
const img = createElement('img', {src: 'https://upload.wikimedia.org/wikipedia/commons/7/74/Red_necked_wallaby444.jpg', alt: 'wallaby'});
const article = createElement('article', {}, h3, p, 'a wallaby is not a computer', img)
mountElement(article, 'body');
