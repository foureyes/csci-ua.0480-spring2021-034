const bcrypt = require('bcryptjs');
const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  username: String,
  password: String, // contains both salt and password in concatenated string
});

mongoose.model('User', UserSchema);

const User = mongoose.model('User');
mongoose.connect('mongodb://localhost/fa20-ait');

function register(username, password, callback) {
  // TODO: (q01) implement register
}

register('foo', 'bar', console.log);
