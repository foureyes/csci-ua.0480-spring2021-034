run npm install to install express, hbs and body-parser:

npm install .
