// make a site that shows a list of snake names
// this list could be stored in memory (if your app restarts
// then the list go disappear)
// add to the list of snake names
// filter the snake names by length
// 1. start off with
//    * steven, hissy elliot, sir hiss a lot
// 2. ^^^ display these as an unordered

const express = require('express');
const app = express();
const snakeNames = ['steven', 'hissy elliot', 'sir hiss a lot'];

const bodyParser = require('body-parser');


function logHello(req, res, next) {
    console.log('hello');
    next();
}
app.use(logHello);

app.use(function(req, res, next) {
    res.set('Server', 'My Super Server!!!');
    next();
});
app.use('/test', function(req, res, next) {
    console.log(req.method, req.path);
    next();
});

// app.use .... register this middleware 
// call the function passed on every request
// that we get
// name1=value1&name2=value2 //ulrencoded
// extended = false treat everything as a string
// req.body
// req.body.name1 <--- as a prop
app.use(bodyParser.urlencoded({extended: false}));
// don't use jade, use the hbs
// module for templating
app.set('view engine', 'hbs');
// /snakes
//


/*
app.use(function(req, res, next) {
    req.unparsedBody.split('&')
        req.body = {}

        add to req.body

            next();
});


app.use((req, res, next) => {
    fs.readFile(req, function(err, data) {
        if(err) {
            next();
        } 
        else... res.sendFile();
    
    }); 
});

*/


app.get('/test', (req, res) => {
  res.send('testing middleware');
});

app.use(function(req, res, next) {
    console.log('after test');
    next();
});

app.get('/', (req, res) => {
    /*
    req.query will contain query string parameters
        as name value pairs (?name1=value1 ... req.query.name1 = value1)
    */
    const DEFAULT_MAX = 40;
    const maxLength = req.query.maxLength || DEFAULT_MAX;

    const filtered = snakeNames.filter(name => name.length < +maxLength);
    // console.log(req.query);
    // 1st arg is name of template sans extensions
    // 2nd arg will be object that specifies values of variables
    // within template
  res.render('home', {maxLength: maxLength, names: filtered, obj: {}, dangerous: "<script>alert('bad stuff here')</script>"});
});

app.post('/snake/add', (req, res) => {
  snakeNames.push(req.body.snakeName);
  // render a template immediately
  // but, convention is to redirect after post
  // redirect because: you don't want to be able to refresh page and get same form submission
  res.redirect('/');
});
app.listen(3000);













