* first 2 pages - short answer / what's the output / defs
* last 3 pages contain 3 coding questions - pick 2
    * hw 2 - hof
    * hw 3 - using the net module / http
    * hw 4 - express
* reference
    * net module
    * handlebars
    * readfile
* read questions carefully ... because i will give you
  code that you don't have to write
* drop closing tags on html
* short answer
    * what's the output
    * definitions
    * t/f or multiple choice
    * short answer 
        * ... what does the http request contain
        * why use templating
* 50 pts for short answer
* 50 pts for coding (choose 2, each is worth 25 points)
    * missing curlies or quotes
    * exact order of params
i'll curve if median / mean are below 77

* x 27 x bind, this, apply and call
* x 21 x creating higher order functions
    * closures
* x 17 x express app - mad libs
* x 16 x prototypes
    * hasownprop vs in vs === undefined
* 16 x build any kind of server using net module
* 13 x reduce, map, filter
* 13 x format of request and response and significant headers













